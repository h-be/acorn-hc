#![cfg_attr(feature = "nightly", feature(proc_macro, generators))]

#[cfg(feature = "nightly")]
mod async_await;
