//! NOT YET AVAILABLE

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct ChainMigrate {}
