#[cfg(feature = "slog")]
// #[macro_use]
// extern crate slog;
// extern crate test;
extern crate uuid;

pub mod parse_str;
