extern crate num;
#[cfg(test)] extern crate rand;

pub use base58::{ToBase58, FromBase58};
pub mod base58;
