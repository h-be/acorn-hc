# rust-base58

Conversion library for [base-58](http://en.wikipedia.org/wiki/Base58).


## Usage

Add this to `Cargo.toml`:

```toml
[dependencies]
rust-base58 = "*"
```
